create
    definer = bank@`%` procedure modifyPassword(IN _idNumber varchar(128), IN newPassword varchar(128),
                                                OUT flag tinyint(1))
begin
    update user set password = newPassword where idNumber = _idNumber;
    if (newPassword = (select password from user where idNumber = _idNumber)) then
        set flag = 1;
    else
        set flag = 0;
    end if;
end;

