CREATE
    DEFINER = bank@`%` PROCEDURE bank_savings(IN _user varchar(128), IN _cardNumber varchar(128), IN _money double,
                                              IN _comment varchar(128), OUT flag tinyint(1))
BEGIN
    SET flag = 0;
    UPDATE card SET money = money + _money WHERE cardNumber = _cardNumber;
    INSERT INTO log VALUES (NULL, _cardNumber, TIMESTAMP(NOW()), _money, '存入', _comment, _user);
    SET flag = 1;
END;

