CREATE
    DEFINER = bank@`%` PROCEDURE open_card(IN _ofIdNumber varchar(128), IN _password varchar(128), IN _money double,
                                           OUT _cardNumber varchar(128), OUT flag int)
BEGIN
    DECLARE cnt INT;
    DECLARE rand INT DEFAULT 100;
    SELECT COUNT(*) INTO cnt FROM card WHERE card.ofIdNumber = _ofIdNumber;
    IF (cnt >= 3) THEN
        SET flag = 0; -- 满3张卡
    ELSE
        -- 生成 3 位的随机数
        SELECT CEILING(RAND() * 900 + 100) INTO rand;
        SET _cardNumber = CONCAT('88888888', DATE_FORMAT(DATE(NOW()), '%Y%m%d'), rand);
        INSERT INTO card(cardNumber, ofIdNumber, password, startTime, money, type, status)
        VALUES (_cardNumber, _ofIdNumber, _password, TIMESTAMP(NOW()), _money, '活期', 1);
        SET flag = 1;
    END IF;
END;

