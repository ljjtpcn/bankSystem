CREATE
    DEFINER = bank@`%` PROCEDURE bank_withdraw(IN _sendCardNumber varchar(128), IN _acceptCardNumber varchar(128),
                                               IN _money double, OUT flag tinyint(1))
BEGIN
    DECLARE sendMoney double DEFAULT 0;
    DECLARE acceptMoney double DEFAULT 0;
    DECLARE sendIdNumber varchar(128);
    DECLARE acceptIdNumber varchar(128);
    SELECT money INTO sendMoney FROM card WHERE cardNumber = _sendCardNumber;
    SELECT money INTO acceptMoney FROM card WHERE cardNumber = _acceptCardNumber;
    SELECT ofIdNumber INTO sendIdNumber FROM card WHERE cardNumber = _sendCardNumber;
    SELECT ofIdNumber INTO acceptIdNumber FROM card WHERE cardNumber = _acceptCardNumber;
    IF (sendMoney - 1 < _money) THEN
        SET flag = 0;
    ELSE
        UPDATE card SET money = money - _money WHERE cardNumber = _sendCardNumber;
        UPDATE card SET money = money + _money WHERE cardNumber = _acceptCardNumber;
        INSERT INTO log VALUES (NULL, _sendCardNumber, DATE(NOW()), _money, '取出', '转账', sendIdNumber);
        INSERT INTO log VALUES (NULL, _acceptCardNumber, DATE(NOW()), _money, '存入', '转账', acceptIdNumber);
        SET flag = 1;
    END IF;
END;

