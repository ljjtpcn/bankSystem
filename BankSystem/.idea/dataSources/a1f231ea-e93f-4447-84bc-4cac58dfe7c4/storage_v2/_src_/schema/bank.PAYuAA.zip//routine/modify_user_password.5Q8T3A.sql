CREATE
    DEFINER = bank@`%` PROCEDURE modify_user_password(IN _idNumber varchar(128), IN _newPassword varchar(128),
                                                      OUT flag tinyint(1))
BEGIN
    SET flag = 0;
    UPDATE user SET password = _newPassword WHERE idNumber = _idNumber;
    SET flag = 1;
END;

