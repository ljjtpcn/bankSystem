CREATE
    DEFINER = bank@`%` PROCEDURE bank_withdraw(IN _user varchar(128), IN _cardNumber varchar(128), IN _money double,
                                               IN _comment varchar(128), OUT flag tinyint(1))
BEGIN
    DECLARE cur_money double DEFAULT 0;
    SELECT money INTO cur_money FROM card WHERE cardNumber = _cardNumber;
    IF (cur_money - 1 < _money) THEN
        SET flag = 0;
    ELSE
        UPDATE card SET money = money - _money WHERE cardNumber = _cardNumber;
        INSERT INTO log VALUES (NULL, _cardNumber, TIMESTAMP(NOW()), _money, '取出', _comment, _user);
        SET flag = 1;
    END IF;
END;

