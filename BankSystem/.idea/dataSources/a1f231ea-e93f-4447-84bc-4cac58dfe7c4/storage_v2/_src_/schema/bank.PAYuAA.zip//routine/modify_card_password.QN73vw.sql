CREATE
    DEFINER = bank@`%` PROCEDURE modify_card_password(IN _cardNumber varchar(128), IN _newPassword varchar(128),
                                                      OUT flag tinyint(1))
BEGIN
    SET flag = 0;
    UPDATE card SET password = _newPassword WHERE _cardNumber = cardNumber;
    SET flag = 1;
END;

