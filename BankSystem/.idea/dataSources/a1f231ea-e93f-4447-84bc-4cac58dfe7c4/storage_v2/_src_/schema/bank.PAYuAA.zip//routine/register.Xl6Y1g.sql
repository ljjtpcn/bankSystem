CREATE
    DEFINER = bank@`%` PROCEDURE register(IN _idNumber varchar(128), IN _password varchar(128), IN _sex varchar(128),
                                          IN _phone varchar(128), OUT flag tinyint(1))
BEGIN
    IF (EXISTS(SELECT * FROM user WHERE _idNumber = user.idNumber)) THEN
        SET flag = 0;
    ELSE
        INSERT INTO user VALUES (NULL, _idNumber, _password, _sex, _phone);
        SET flag = 1;
    END IF;
END;

