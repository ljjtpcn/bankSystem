CREATE
    DEFINER = bank@`%` PROCEDURE login(IN _idNumber varchar(128), IN _password varchar(128), OUT flag tinyint(1))
BEGIN
    IF (_password = (SELECT password FROM user WHERE user.idNumber = _idNumber)) THEN
        SET flag = 1;
    ELSE
        SET flag = 0;
    END IF;
END;

